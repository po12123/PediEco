<?php
error_reporting(0);
session_start();
include 'includes/conecta.php';

$usuario = $_SESSION['Usuario'];
$idProducto = $conecta -> real_escape_string($_POST['idpro']);
$consulta = "SELECT * FROM carrito WHERE Id_Clientes = '$usuario' AND Id_Producto = '$idProducto'";

if($resultado = $conecta->query($consulta)){
    while($row = $resultado->fetch_array()){
        $idok = $row['id_Producto'];
    }
    $resultado->close();
}

if($idProducto == $idok){
    $sql = "DELETE FROM carrito WHERE Id_Clientes = '$usuario' AND Id_Producto = '$idProducto'";
    if($resultado = $conecta->query($sql)){
        $resultado->close();
    }
}

?>
