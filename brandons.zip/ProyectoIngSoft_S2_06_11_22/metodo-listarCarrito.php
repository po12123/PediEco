<?php
session_start();
error_reporting(0);
include('includes/conecta.php');
$usuario = $_SESSION['Usuario'];
try {
    $sql= "SELECT * FROM carrito WHERE Id_Clientes = '$usuario'";
    $resultado=mysqli_query($conecta,$sql); 
    $resultado3 = mysqli_query($conecta,$sql);  
    $data = [];
    while($mostrar=mysqli_fetch_array($resultado))
    {
        
        $cantidadProducto=$mostrar['Cantidad_X_Producto'];
        $datosProducto = "SELECT * FROM producto WHERE Id_Producto = $mostrar[id_Producto]";
        if($result = $conecta->query($datosProducto)){
            while($row = $result->fetch_array()){
                $idProducto= $row['id_Producto'];
                $nombreProducto = $row['Nombres_Producto'];
                $imagenProducto = $row['Imagen_Producto'];
                $precioProducto = $row['Precio_Producto']; 
                $maxProducto = $row['Cantidad_Producto']; 
                $data[] = [
                    'id' => $mostrar['id_Producto'],
                    'imagen' => base64_encode($imagenProducto),
                    'nombre' => $nombreProducto,
                    'precio' => $precioProducto,
                    'cantidad' => $cantidadProducto,
                    'max' => $maxProducto,
                ];
            } 
            $result->close();
        }
    }
    echo json_encode($data);
} catch(Exception $error) {
    echo $error->getMessage();
}