<?php
error_reporting(0);
session_start();
include 'includes/conecta.php';
        $usuario = $_SESSION['Usuario'];
            $idProducto= $conecta -> real_escape_string($_POST['idP']);
            $consulta = "SELECT * FROM carrito WHERE Id_Clientes = '$usuario' and Id_Producto = '$idProducto'";
            if($resultado = $conecta->query($consulta)){
                while($row = $resultado->fetch_array()){
                    $idok = $row['id_Producto'];
                }
                $resultado->close();
            }
            if($idProducto == $idok){
                $consulta = "DELETE FROM carrito WHERE Id_Clientes = '$usuario' and id_Producto = '$idProducto'";
                if($resultado = $conecta->query($consulta)){
                    $resultado->close();
                }
            }
?>