<?php
error_reporting(0);
session_start();
include 'includes/conecta.php';
        $usuario = $_SESSION['Usuario'];
            $idProducto= $conecta -> real_escape_string($_POST['idP']);
            $cantidadProducto= $conecta -> real_escape_string($_POST['canP']);
            $precioProducto= $conecta -> real_escape_string($_POST['preP']);
            $consulta = "SELECT * FROM carrito WHERE Id_Clientes = '$usuario' and Id_Producto = '$idProducto'";
            if($resultado = $conecta->query($consulta)){
                while($row = $resultado->fetch_array()){
                    $idok = $row['id_Producto'];
                    $cantidadok = $row['Cantidad_X_Producto'];
                }
                $resultado->close();
            }
            if($idProducto == $idok){
                $montoTotal=$precioProducto*$cantidadProducto;
                $consulta = "UPDATE carrito SET Cantidad_X_Producto = '$cantidadProducto', MontoTotal_X_Producto = '$montoTotal' WHERE Id_Clientes = '$usuario' and id_Producto = '$idProducto'";
                if($resultado = $conecta->query($consulta)){
                    $resultado->close();
                }
            }
?>