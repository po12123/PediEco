function eliminar(idProducto, idCliente){
    subirBD_PCE(idProducto, idCliente);
}
const subirBD_PCE=(idProducto, idCliente)=>{
	let formData = new FormData();
	formData.append("idpro", idProducto);
	formData.append("idcli", idCliente);

    fetch("metodo-subirBD_PCEliminar.php", {
	method: 'POST',
	body: formData,
	});
    alert("Se ha eliminado el producto del carrito");
}
