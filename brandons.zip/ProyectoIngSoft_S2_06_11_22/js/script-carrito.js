
fetch('metodo-listarCarrito.php')
.then(res => res.json())
.then(data => {

    // console.log(data);
    let str = '';
    data.map(item => {
        str += `
        <div class="row shoppingCartItem">
              <div class="col-6">
                  <div class="shopping-cart-item d-flex align-items-center h-100 border-bottom pb-2 pt-3">
                      <img src="data:image/png;base64,${item.imagen}" class="shopping-cart-image" width="150" height="150">
                      <h6 class="shopping-cart-item-title shoppingCartItemTitle text-truncate ml-3 mb-0">${item.nombre}</h6>
                  </div>
              </div>
              <div class="col-2">
                  <div class="shopping-cart-price d-flex align-items-center h-100 border-bottom pb-2 pt-3">
                      <p class="item-price mb-0 shoppingCartItemPrice">${item.precio} Bs</p>
                  </div>
              </div>
              <div class="col-4">
                  <div
                      class="shopping-cart-quantity d-flex justify-content-between align-items-center h-100 border-bottom pb-2 pt-3">
                      <input onclick="cambiarCantidad(${item.id},${item.precio})" min="1" max="${item.max}" class="shopping-cart-quantity-input shoppingCartItemQuantity" id="can${item.id}" type="number"
                          value=${item.cantidad}>
                      <a onclick="eliminar(${item.id})" class="btn btn-danger buttonDelete" type="button">X</a>
                  </div>
              </div>
          </div>`
    });
    const shoppingCartItemsContainer = document.querySelector(
      '.shoppingCartItemsContainer'
    );
    const elementsTitle = shoppingCartItemsContainer.getElementsByClassName(
      'shoppingCartItemTitle'
    );
    const shoppingCartRow = document.createElement('div');
    shoppingCartRow.innerHTML = str;
    shoppingCartItemsContainer.append(shoppingCartRow);
    cambiarTotal();

});

function eliminar (idProducto){
  let formData = new FormData();
	formData.append("idP", idProducto);
  fetch("metodo-eliminar_PC.php", {
	method: 'POST',
	body: formData,
	});
  location.reload();
}
function cambiarCantidad(idProducto, pProducto){
  var cantidad=document.getElementById('can'+idProducto).value;
  console.log("cambiar");
  console.log(idProducto);
  console.log(cantidad);
  actualizarCarrito(idProducto, cantidad, pProducto);
  cambiarTotal();
}
function actualizarCarrito(idProducto, cantidad, precio){
  let formData = new FormData();
	formData.append("idP", idProducto);
  formData.append("canP", cantidad);
  formData.append("preP", precio);
  fetch("metodo-cambiarCantidad_PC.php", {
	method: 'POST',
	body: formData,
	}); 
}
function cambiarTotal() {
  let total = 0;
  const shoppingCartTotal = document.querySelector('.shoppingCartTotal');

  const shoppingCartItems = document.querySelectorAll('.shoppingCartItem');

  shoppingCartItems.forEach((shoppingCartItem) => {
    const shoppingCartItemPriceElement = shoppingCartItem.querySelector(
      '.shoppingCartItemPrice'
    );
    const shoppingCartItemPrice = Number(
      shoppingCartItemPriceElement.textContent.replace('Bs', '')
    );
    const shoppingCartItemQuantityElement = shoppingCartItem.querySelector(
      '.shoppingCartItemQuantity'
    );
    const shoppingCartItemQuantity = Number(
      shoppingCartItemQuantityElement.value
    );
    total = total + shoppingCartItemPrice * shoppingCartItemQuantity;
  });
  shoppingCartTotal.innerHTML = `${total.toFixed(2)}Bs`;
}