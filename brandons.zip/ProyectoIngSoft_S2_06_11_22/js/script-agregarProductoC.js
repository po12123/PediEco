function agregar2(id, precio){
    subirBD_PC2(id, precio);
}

const subirBD_PC2=(id, precio)=>{
	let formData = new FormData();
	var cantidad=document.getElementById('canti'+id).value;
	formData.append("id", id);
	formData.append("pre", precio);
    formData.append("cann", cantidad);


    fetch("metodo-subirBD_PCC.php", {
	method: 'POST',
	body: formData,
	});
}



