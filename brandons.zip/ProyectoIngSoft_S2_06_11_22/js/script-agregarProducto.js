function agregar(id, precio, cantidadProducto){
    subirBD_PC(id, precio, cantidadProducto);
}

const subirBD_PC=(id, precio, cantidadProducto)=>{
	let formData = new FormData();
	var cantidad=document.getElementById('cant').value;
	formData.append("id", id);
	formData.append("pre", precio);
    formData.append("can", cantidad);


	if(cantidad>cantidadProducto){
		alert("No hay suficiente cantidad de producto");
	}else{
    	fetch("metodo-subirBD_PC.php", {
		method: 'POST',
		body: formData,
		});
	}
}



